package com.infosys.Capstone.Capstone_Project_1108358;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class LoginAutomaion {
	
	 public static void main(String[] args) throws InterruptedException, IOException {
	
		      WebDriver driver;
			  System.setProperty("webdriver.chrome.driver","F:\\Software\\chromedriver_win32\\chromedriver.exe");
			  driver=new ChromeDriver();
			  driver.get("path of the html page");
			  FileInputStream fi = new FileInputStream("F:\\Major Project\\Selenium\\Credentials.xls");
			  XSSFWorkbook wbook=new XSSFWorkbook(fi);
			  XSSFSheet sheet =wbook.getSheet("Sheet1");
			  int rowCount=sheet.getLastRowNum();
			  for(int i=1;i<=rowCount;i++)
			  {

				  	String userName=sheet.getRow(i).getCell(0).toString();
				  	String password=sheet.getRow(i).getCell(1).toString();
				  	System.out.println(userName);
				  	System.out.println(password);
				  	
				  	driver.findElement(By.id("")).sendKeys(userName);
				  	Thread.sleep(5000);
					driver.findElement(By.id("")).sendKeys(password);
				 	Thread.sleep(5000);
				  	driver.findElement(By.className("")).click();

			        if(userName.equals("donhere") && password.equals("don@123"))
			        {
			           driver.navigate().to("Path to next page");
			        }
			        else
			        {
			        	 String errorMessage= driver.findElement(By.id("")).getText();
			        	Assert.assertEquals("Incorrect Username/Password", errorMessage);

			        }


			     }
			      driver.quit();
			    }
		
		
	}


